document.addEventListener('DOMContentLoaded', () => {
    // Configuração do carrossel de créditos
    const creditosCarrossel = document.querySelector('.creditos-container');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const cardWidth = document.querySelector('.card-credito').offsetWidth + 30;
    let currentPosition = 0;
    const maxVisibleCards = 4;
    const totalCards = document.querySelectorAll('.card-credito').length;
    const maxPosition = -((totalCards - maxVisibleCards) * cardWidth);
    
    // Adicionando container de dots
    const dotsContainer = document.createElement('div');
    dotsContainer.classList.add('carousel-dots');
    document.querySelector('.creditos-section').appendChild(dotsContainer);
    
    // Criando dots
    const totalSlides = Math.ceil(totalCards / maxVisibleCards);
    for (let i = 0; i < totalSlides; i++) {
        const dot = document.createElement('button');
        dot.classList.add('dot');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
    }
    
    const dots = document.querySelectorAll('.dot');
    
    // Funções de navegação
    function updateCarrossel() {
        creditosCarrossel.style.transform = `translateX(${currentPosition}px)`;
        updateDots();
    }
    
    function updateDots() {
        const activeDot = Math.abs(Math.round(currentPosition / (cardWidth * maxVisibleCards)));
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === activeDot);
        });
    }
    
    function goToSlide(slideIndex) {
        currentPosition = -(slideIndex * cardWidth * maxVisibleCards);
        // Garante que não vá além dos limites
        if (currentPosition < maxPosition) currentPosition = maxPosition;
        if (currentPosition > 0) currentPosition = 0;
        updateCarrossel();
    }
    
    function nextSlide() {
        if (currentPosition > maxPosition) {
            currentPosition -= cardWidth * maxVisibleCards;
            if (currentPosition < maxPosition) currentPosition = maxPosition;
            updateCarrossel();
        }
    }
    
    function prevSlide() {
        if (currentPosition < 0) {
            currentPosition += cardWidth * maxVisibleCards;
            if (currentPosition > 0) currentPosition = 0;
            updateCarrossel();
        }
    }
    
    // Event listeners para as setas
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
    
    // Auto-avanço
    let autoAdvance = setInterval(nextSlide, 5000);
    
    // Pausar ao passar o mouse
    const carrosselSection = document.querySelector('.creditos-section');
    carrosselSection.addEventListener('mouseenter', () => {
        clearInterval(autoAdvance);
    });
    
    carrosselSection.addEventListener('mouseleave', () => {
        autoAdvance = setInterval(nextSlide, 5000);
    });
    
    // Navegação por teclado
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') prevSlide();
        if (e.key === 'ArrowRight') nextSlide();
    });
    
    // Suporte a touch
    let touchStartX = 0;
    let touchEndX = 0;
    
    creditosCarrossel.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    });
    
    creditosCarrossel.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            if (diff > 0) {
                nextSlide();
            } else {
                prevSlide();
            }
        }
    }
});